#Contoh Versi 3 OOP class#

class Segitiga:
    def __init__(self):
        self._tinggi = None
        self._alas = None
        
    @property
    def alas(self):
        return self._alas
    
    @alas.setter
    def alas(self, value):
        self._alas = value
        
    @property
    def tinggi(self):
        return self._tinggi
    
    @tinggi.setter
    def tinggi(self, value):
        self._tinggi = value
        
    def Luas(self):
        return 0.5 * self._alas * self._tinggi
    
S = Segitiga()
A = input("Masukkan Nilai Alas :")
T = input("Masukkan Nilai Tinggi :")

S.alas = int(A)
S.tinggi = int(T)

L = S.Luas()

print("Alas Sebesar :", A)
print("Tinggi Sebesar :", T)
print("Jadi Hasil LuasNya sebesar :", L)
